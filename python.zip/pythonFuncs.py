import Survey
def correct_myfile(old_survey_path):
    file=open(old_survey_path,'r')
    dict={}
    for line in file:
        sentence=line.split()
        id=sentence[0]
        age=sentence[2]
        scores=sentence[4:]
        if len(id)!=8 or age<'0' or age>'100':
            continue
        for x in scores:
            if x<'1' or x>'10':
                continue
        dict['age']=sentence[1:]

    for k ,v in dict.items():
       print(k+v)

    file.close()

def scan_survey(survey_path):
    file=open(survey_path,'r')
    survey=Survey.SurveyCreateSurvey()
    for line in file:
        sentence=line.split()
        id=sentence[0]
        EatingHabits=sentence[1]
        age=sentence[2]
        gender=sentence[3]
        scores=sentence[4:]
        Survey.SurveyAddPerson(Survey,id,age,gender, EatingHabits , Scores)
    file.close()
    return survey

def print_info(s, choc_type, gender, min_age, max_age, eating_habits):
    size=10
    val=0
    array=Survey.SurveyCreateIntAr(size)
    histogram=Survey.SurveyQuerySurvey(s,choc_type,gender,min_age,max_age,eating_habits)
    for index in range(size):
        val=histogram.count(index)
        Survey.SurveySetIntArIdxVal(array, index, val)
    for index in range(size):
        x=Survey.SurveyGetIntArIdxVal(arrray,index)
        print(x)
    Survey.SurveyQueryDestroy(histogram)
    Survey.SurveyDestoryIntAr(array)


def clear_survey(s):
    Survey.SurveyDestroySurvey(s)

